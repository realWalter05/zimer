import zikasort

def main():
	zikasort.main()
