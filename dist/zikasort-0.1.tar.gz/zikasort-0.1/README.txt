Reorders/reverses/renames files in a folder.
